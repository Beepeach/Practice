//
//  Person.swift
//  sendTableView200925
//
//  Created by JunHee Jo on 2020/09/26.
//

import Foundation

struct Person {
    let name: String
    let address: String
}

