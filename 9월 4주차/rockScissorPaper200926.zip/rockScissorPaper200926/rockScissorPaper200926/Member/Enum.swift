//
//  Enum.swift
//  rockScissorPaper200926
//
//  Created by JunHee Jo on 2020/09/27.
//

import Foundation

enum RockScissorsPaper: Int {
    case rock = -1
    case scissors = 0
    case paper = 1
}
